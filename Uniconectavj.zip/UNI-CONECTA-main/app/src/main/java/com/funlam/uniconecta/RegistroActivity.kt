package com.funlam.uniconecta

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.funlam.uniconecta.compose.BottomAppBarMapa
import com.funlam.uniconecta.compose.MainScreen
import com.funlam.uniconecta.compose.MyAppTheme

class RegistroActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_registrarse)


        val btnregreregis = findViewById<ImageButton>(R.id.btnregreregis)

        btnregreregis.setOnClickListener{
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }
                
            }
        }


